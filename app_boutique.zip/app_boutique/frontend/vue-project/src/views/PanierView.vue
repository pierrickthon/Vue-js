<template>
    <div class="panier-view">
      <h1>Votre panier</h1>
      
      <div v-if="panier.length === 0" class="panier-vide">
        <p>Votre panier est vide.</p>
        <router-link to="/articles" class="btn">Parcourir les articles</router-link>
      </div>
      
      <div v-else class="panier-plein">
        <div class="panier-articles">
          <div v-for="article in panier" :key="article.id" class="panier-item">
            <div class="article-image">
              <img :src="article.image" :alt="article.titre" />
            </div>
            <div class="article-details">
              <h3>{{ article.titre }}</h3>
              <p class="description">{{ article.description }}</p>
            </div>
            <div class="article-price">
              {{ article.prix.toFixed(2) }} €
            </div>
            <div class="article-actions">
              <button @click="supprimerDuPanier(article.id)" class="btn-remove">
                Supprimer
              </button>
            </div>
          </div>
        </div>
        
        <div class="panier-resume">
          <h2>Résumé de la commande</h2>
          <div class="resume-ligne">
            <span>Nombre d'articles:</span>
            <span>{{ panier.length }}</span>
          </div>
          <div class="resume-ligne total">
            <span>Total:</span>
            <span>{{ totalPanier.toFixed(2) }} €</span>
          </div>
          <div class="panier-actions">
            <button @click="validerCommande" class="btn btn-commander">
              Valider la commande
            </button>
            <button @click="viderPanier" class="btn btn-vider">
              Vider le panier
            </button>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'PanierView',
    computed: {
      panier() {
        return this.$store.state.panier
      },
      totalPanier() {
        return this.$store.getters.getTotalPanier
      }
    },
    methods: {
      supprimerDuPanier(id) {
        this.$store.commit('supprimerDuPanier', id)
      },
      viderPanier() {
        if (confirm('Êtes-vous sûr de vouloir vider votre panier ?')) {
          this.$store.commit('viderPanier')
        }
      },
      validerCommande() {
        alert('Commande validée ! Ceci est une démonstration, aucune commande réelle n\'a été passée.')
        this.$store.commit('viderPanier')
        this.$router.push('/')
      }
    }
  }
  </script>
  
  <style scoped>
  .panier-view {
    max-width: 1000px;
    margin: 0 auto;
    padding: 20px;
  }
  
  h1 {
    margin-bottom: 30px;
    text-align: center;
    color: #333;
  }
  
  .panier-vide {
    text-align: center;
    padding: 40px;
    background-color: #f8f8f8;
    border-radius: 8px;
  }
  
  .panier-vide p {
    font-size: 1.2rem;
    margin-bottom: 20px;
    color: #666;
  }
  
  .btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-decoration: none;
    font-weight: bold;
  }
  
  .panier-plein {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 30px;
  }
  
  .panier-articles {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
  }
  
  .panier-item {
    display: grid;
    grid-template-columns: 80px 1fr auto auto;
    gap: 15px;
    padding: 15px 0;
    border-bottom: 1px solid #eee;
    align-items: center;
  }
  
  .panier-item:last-child {
    border-bottom: none;
  }
  
  .article-image img {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 4px;
  }
  
  .article-details h3 {
    margin-bottom: 5px;
    font-size: 1.1rem;
  }
  
  .description {
    color: #666;
    font-size: 0.9rem;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  
  .article-price {
    font-weight: bold;
    color: #42b983;
  }
  
  .btn-remove {
    padding: 6px 12px;
    background-color: #f44336;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  .panier-resume {
    background-color: #f8f8f8;
    border-radius: 8px;
    padding: 20px;
    align-self: start;
  }
  
  .panier-resume h2 {
    margin-bottom: 20px;
    font-size: 1.3rem;
    color: #333;
  }
  
  .resume-ligne {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding-bottom: 10px;
    border-bottom: 1px solid #ddd;
  }
  
  .total {
    font-weight: bold;
    font-size: 1.2rem;
    color: #333;
    margin-top: 10px;
    margin-bottom: 20px;
  }
  
  .panier-actions {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  
  .btn-commander {
    background-color: #42b983;
    color: white;
  }
  
  .btn-vider {
    background-color: #6c757d;
    color: white;
  }
  
  @media (max-width: 768px) {
    .panier-plein {
      grid-template-columns: 1fr;
    }
  }
  </style>