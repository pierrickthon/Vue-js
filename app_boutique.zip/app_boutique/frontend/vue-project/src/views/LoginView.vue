<template>
    <div class="login-container">
      <form @submit.prevent="connexion" class="login-form">
        <h2>Connexion</h2>
        
        <div class="form-group">
          <label for="email">Email</label>
          <input 
            type="email" 
            id="email" 
            v-model="formData.email" 
            required
          />
        </div>

        <div class="form-group">
          <label for="password">Mot de passe</label>
          <input 
            type="password" 
            id="password" 
            v-model="formData.password" 
            required
          />
        </div>

        <div v-if="erreur" class="error-message">
          {{ erreur }}
        </div>

        <button type="submit" class="btn-login">Se connecter</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    name: 'LoginView',
    data() {
      return {
        formData: {
          email: '',
          password: ''
        },
        erreur: null
      }
    },
    methods: {
      async connexion() {
        try {
          this.erreur = null
          await this.$store.dispatch('login', this.formData)
          this.$router.push('/')
        } catch (error) {
          this.erreur = error.message || "Une erreur s'est produite lors de la connexion"
        }
      }
    }
  }
  </script>
  
  <style scoped>
  .login-container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 80vh;
  }
  
  .login-form {
    width: 100%;
    max-width: 400px;
    padding: 30px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  h2 {
    text-align: center;
    margin-bottom: 30px;
    color: #333;
  }
  
  .form-group {
    margin-bottom: 20px;
  }
  
  label {
    display: block;
    margin-bottom: 5px;
    color: #333;
  }
  
  input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 16px;
  }
  
  .btn-login {
    width: 100%;
    padding: 12px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
  }
  
  .btn-login:hover {
    background-color: #3aa876;
  }
  
  .error-message {
    color: #dc3545;
    margin-bottom: 15px;
    text-align: center;
  }
  </style>