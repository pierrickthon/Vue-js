<template>
    <div class="articles-view">
      <h1>Tous nos articles</h1>
      <BarreRecherche @recherche="updateRecherche" />
      <ListeArticles :articles="articles" :recherche="termeRecherche" />
    </div>
  </template>
  
  <script>
  import BarreRecherche from '../components/BarreRecherche.vue'
  import ListeArticles from '../components/ListeArticles.vue'

  export default {
    name: 'ArticlesView',
    components: {
      BarreRecherche,
      ListeArticles
    },
    data() {
      return {
        termeRecherche: ''
      }
    },
    computed: {
      articles() {
        return this.$store.state.articles
      }
    },
    created() {
      // Charger les articles au montage du composant
      this.chargerArticles()
    },
    methods: {
      updateRecherche(terme) {
        this.termeRecherche = terme
      },
      supprimerArticle(id) {
        const articles = this.$store.state.articles
        this.$store.commit('setArticles', articles.filter(article => article.id !== id))
      },
      async chargerArticles() {
        try {
          // Si vous avez une action dans votre store pour charger les articles
          await this.$store.dispatch('chargerArticles')
        } catch (error) {
          console.error('Erreur lors du chargement des articles:', error)
        }
      }
    }
  }
  </script>
  <style scoped>
  .articles-view {
    max-width: 1200px;
    margin: 0 auto;
  }
  
  h1 {
    margin-bottom: 30px;
    text-align: center;
    color: #333;
  }
  </style>