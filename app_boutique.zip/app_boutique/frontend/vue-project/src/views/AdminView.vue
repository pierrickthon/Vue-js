<template>
    <div class="admin-view">
      <div class="admin-header">
        <h1>Administration des articles</h1>
        <div class="admin-actions">
          <button @click="deconnexion" class="btn btn-logout">
            Se déconnecter
          </button>
        </div>
      </div>
      
      <div class="admin-content">
        <BarreRecherche @recherche="updateRecherche" />
        
        <div class="admin-stats">
          <div class="stat-card">
            <h3>Total des articles</h3>
            <p class="stat-value">{{ articles.length }}</p>
          </div>
          <div class="stat-card">
            <h3>Articles au panier</h3>
            <p class="stat-value">{{ panier.length }}</p>
          </div>
          <div class="stat-card">
            <h3>Valeur du stock</h3>
            <p class="stat-value">{{ valeurTotale.toFixed(2) }} €</p>
          </div>
        </div>
        
        <div class="admin-table-container">
          <h2>Gestion des articles</h2>
          <table class="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Titre</th>
                <th>Prix</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="article in articlesFiltres" :key="article.id">
                <td>{{ article.id }}</td>
                <td>
                  <img :src="article.image" :alt="article.titre" class="thumbnail" />
                </td>
                <td>{{ article.titre }}</td>
                <td>{{ article.prix.toFixed(2) }} €</td>
                <td>
                  <div class="article-actions">
                    <router-link :to="`/article/${article.id}`" class="btn btn-view">
                      Voir
                    </router-link>
                    <button @click="supprimerArticle(article)" class="btn btn-delete">
                      Supprimer
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div v-if="articlesFiltres.length === 0" class="no-results">
          Aucun article ne correspond à votre recherche.
        </div>
        
        <div class="admin-add-section">
          <h2>Ajouter un nouvel article</h2>
          <router-link to="/ajouter" class="btn btn-add">
            Créer un nouvel article
          </router-link>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import BarreRecherche from '@/components/BarreRecherche.vue'
  
  export default {
    name: 'AdminView',
    components: {
      BarreRecherche
    },
    data() {
      return {
        termeRecherche: ''
      }
    },
    computed: {
      articles() {
        return this.$store.state.articles
      },
      panier() {
        return this.$store.state.panier
      },
      articlesFiltres() {
        if (!this.termeRecherche) return this.articles
        
        const recherche = this.termeRecherche.toLowerCase()
        return this.articles.filter(article => 
          article.titre.toLowerCase().includes(recherche) || 
          article.description.toLowerCase().includes(recherche)
        )
      },
      valeurTotale() {
        return this.articles.reduce((total, article) => total + article.prix, 0)
      }
    },
    methods: {
      updateRecherche(terme) {
        this.termeRecherche = terme
      },
      supprimerArticle(article) {
        if (confirm(`Êtes-vous sûr de vouloir supprimer "${article.titre}" ?`)) {
          this.$store.commit('supprimerArticle', article.id)
        }
      },
      deconnexion() {
        this.$store.commit('setLoggedIn', false)
        this.$router.push('/login')
      }
    }
  }
  </script>
  
  <style scoped>
  .admin-view {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
  }
  
  .admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
  }
  
  .admin-header h1 {
    margin: 0;
    color: #333;
  }
  
  .btn {
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
    text-decoration: none;
    display: inline-block;
    text-align: center;
  }
  
  .btn-logout {
    background-color: #dc3545;
    color: white;
  }
  
  .admin-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
  }
  
  .stat-card {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  }
  
  .stat-card h3 {
    margin-top: 0;
    margin-bottom: 10px;
    font-size: 1rem;
    color: #555;
  }
  
  .stat-value {
    font-size: 1.8rem;
    font-weight: bold;
    margin: 0;
    color: #42b983;
  }
  
  .admin-table-container {
    background-color: #fff;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 30px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }
  
  .admin-table-container h2 {
    margin-top: 0;
    margin-bottom: 20px;
    color: #333;
  }
  
  .admin-table {
    width: 100%;
    border-collapse: collapse;
  }
  
  .admin-table th,
  .admin-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #eee;
  }
  
  .admin-table th {
    background-color: #f8f9fa;
    font-weight: bold;
    color: #333;
  }
  
  .thumbnail {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 4px;
  }
  
  .article-actions {
    display: flex;
    gap: 10px;
  }
  
  .btn-view {
    background-color: #007bff;
    color: white;
  }
  
  .btn-delete {
    background-color: #dc3545;
    color: white;
  }
  
  .no-results {
    text-align: center;
    padding: 30px;
    background-color: #f8f8f8;
    border-radius: 8px;
    margin-bottom: 30px;
  }
  
  .admin-add-section {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  }
  
  .admin-add-section h2 {
    margin-top: 0;
    margin-bottom: 20px;
    color: #333;
  }
  
  .btn-add {
    background-color: #42b983;
    color: white;
    padding: 12px 24px;
    font-size: 1rem;
  }
  </style>