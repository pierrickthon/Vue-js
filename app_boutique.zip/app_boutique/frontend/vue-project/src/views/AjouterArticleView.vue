<template>
    <div class="ajouter-article-view">
      <FormulaireArticle 
        titre="Ajouter un nouvel article" 
        boutonTexte="Ajouter l'article"
        @soumettre="ajouterArticle"
      />
      <div v-if="messageSucces" class="success-message">
        <p>{{ messageSucces }}</p>
        <div class="success-actions">
          <router-link to="/articles" class="btn">Voir tous les articles</router-link>
          <button @click="ajouterAutre" class="btn">Ajouter un autre article</button>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import FormulaireArticle from '@/components/FormulaireArticle.vue'
  
  export default {
    name: 'AjouterArticleView',
    components: {
      FormulaireArticle
    },
    data() {
      return {
        messageSucces: ''
      }
    },
    methods: {
      ajouterArticle(nouvelArticle) {
        this.$store.commit('ajouterArticle', nouvelArticle)
        this.messageSucces = `L'article "${nouvelArticle.titre}" a été ajouté avec succès !`
      },
      ajouterAutre() {
        this.messageSucces = ''
      }
    }
  }
  </script>
  
  <style scoped>
  .ajouter-article-view {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
  }
  
  .success-message {
    margin-top: 30px;
    padding: 20px;
    background-color: #d4edda;
    border-radius: 4px;
    color: #155724;
    text-align: center;
  }
  
  .success-actions {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-top: 15px;
  }
  
  .btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-decoration: none;
    font-weight: bold;
  }
  </style>