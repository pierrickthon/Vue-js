<template>
    <div class="home">
      <h1>Bienvenue sur notre boutique en ligne</h1>
      <div class="intro">
        <p>Découvrez notre sélection d'articles exceptionnels à des prix imbattables.</p>
        <router-link to="/articles" class="cta-button">Voir tous les articles</router-link>
      </div>
      
      <section class="featured-products">
        <h2>Articles populaires</h2>
        <div class="products-preview">
          <ArticleItem 
            v-for="article in articlesPopulaires" 
            :key="article.id" 
            :article="article"
          />
        </div>
      </section>
    </div>
  </template>
  
  <script>
  import ArticleItem from '@/components/ArticleItem.vue'
  
  export default {
    name: 'HomeView',
    components: {
      ArticleItem
    },
    computed: {
      articlesPopulaires() {
        // Afficher les 3 premiers articles comme "populaires"
        return this.$store.state.articles.slice(0, 3)
      }
    }
  }
  </script>
  
  <style scoped>
  .home {
    text-align: center;
  }
  
  h1 {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    color: #333;
  }
  
  .intro {
    max-width: 800px;
    margin: 0 auto 40px;
  }
  
  .intro p {
    font-size: 1.2rem;
    color: #666;
    margin-bottom: 20px;
  }
  
  .cta-button {
    display: inline-block;
    background-color: #42b983;
    color: white;
    padding: 12px 24px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: bold;
    transition: background-color 0.3s;
  }
  
  .cta-button:hover {
    background-color: #3a9f72;
  }
  
  .featured-products {
    margin-top: 40px;
  }
  
  .featured-products h2 {
    margin-bottom: 20px;
    color: #333;
  }
  
  .products-preview {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
  }
  </style>