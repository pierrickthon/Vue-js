<template>
    <div class="article-detail">
      <div v-if="article" class="article-container">
        <div class="article-image">
          <img :src="article.image" :alt="article.titre" />
        </div>
        <div class="article-info">
          <h1>{{ article.titre }}</h1>
          <p class="description">{{ article.description }}</p>
          <p class="prix">{{ article.prix.toFixed(2) }} €</p>
          <div class="actions">
            <button @click="ajouterAuPanier" class="btn btn-primary">Ajouter au panier</button>
            <router-link to="/articles" class="btn btn-secondary">Retour aux articles</router-link>
          </div>
        </div>
      </div>
      <div v-else class="article-not-found">
        <h2>Article non trouvé</h2>
        <p>L'article que vous recherchez n'existe pas ou a été supprimé.</p>
        <router-link to="/articles" class="btn btn-primary">Voir tous les articles</router-link>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'ArticleDetailView',
    computed: {
      article() {
        const id = parseInt(this.$route.params.id)
        return this.$store.getters.getArticleById(id)
      }
    },
    methods: {
      ajouterAuPanier() {
        if (this.article) {
          this.$store.commit('ajouterAuPanier', this.article)
          alert(`"${this.article.titre}" a été ajouté au panier !`)
        }
      }
    }
  }
  </script>
  
  <style scoped>
  .article-detail {
    max-width: 1000px;
    margin: 0 auto;
    padding: 20px;
  }
  
  .article-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 40px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 30px;
  }
  
  .article-image img {
    width: 100%;
    height: auto;
    border-radius: 8px;
    object-fit: cover;
  }
  
  .article-info h1 {
    font-size: 1.8rem;
    margin-bottom: 15px;
    color: #333;
  }
  
  .description {
    margin-bottom: 20px;
    line-height: 1.6;
    color: #555;
  }
  
  .prix {
    font-size: 1.5rem;
    font-weight: bold;
    color: #42b983;
    margin-bottom: 25px;
  }
  
  .actions {
    display: flex;
    gap: 15px;
  }
  
  .btn {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
  }
  
  .btn-primary {
    background-color: #42b983;
    color: white;
  }
  
  .btn-secondary {
    background-color: #6c757d;
    color: white;
  }
  
  .article-not-found {
    text-align: center;
    padding: 50px 20px;
    background-color: #f8f8f8;
    border-radius: 8px;
  }
  
  .article-not-found h2 {
    margin-bottom: 15px;
    color: #333;
  }
  
  .article-not-found p {
    margin-bottom: 20px;
    color: #666;
  }
  
  @media (max-width: 768px) {
    .article-container {
      grid-template-columns: 1fr;
    }
  }
  </style>