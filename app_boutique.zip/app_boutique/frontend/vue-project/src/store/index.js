import { createStore as vuexCreateStore } from 'vuex'

// Données d'exemple pour les articles
const articlesInitiaux = [
  { id: 1, titre: 'pc HP New gen', description: 'Ordinateur Portable 16 GO RAM', prix: 1999.99, image: 'https://www.backmarket.fr/cdn-cgi/image/format%3Dauto%2Cquality%3D75%2Cwidth%3D260/https://d2e6ccujb3mkqf.cloudfront.net/b16f5679-9782-48d7-8fe6-b5dee941f94d-1_1ef6ea85-c56e-4499-b8ff-aec213b6a32a.jpg'},
  { id: 2, titre: 'Macbook Air', description: 'Apple macbook air nouvelle génération', prix: 939.99, image: 'https://d2e6ccujb3mkqf.cloudfront.net/0d728417-a988-4c36-a758-678fb4a2a4e7-1_2ca0a3b9-bddb-4e24-a9f3-99cef614f458.jpg' },
  { id: 3, titre: 'Pc AZUS', description: 'Pc gaming 300fps 500 Giga RAM', prix: 679.99, image: 'https://www.backmarket.fr/cdn-cgi/image/format%3Dauto%2Cquality%3D75%2Cwidth%3D260/https://d2e6ccujb3mkqf.cloudfront.net/e828cae8-51b6-4c60-8ea3-224c57234def-1_5798b547-2c9e-44d8-9f31-c50b6c5ec0ad.jpg' },
  { id: 4, titre: 'Ipad ', description: 'Ipad pour pc. Parfait pour les étudiants', prix: 49.99, image: 'https://d2e6ccujb3mkqf.cloudfront.net/4df84574-ea66-428a-9755-2bbcdbac3ed7-1_aefe5f2b-6340-458f-bb4f-1f36d05b6c16.jpg' }
]

// Récupération du panier depuis le localStorage s'il existe
const panierLocalStorage = localStorage.getItem('panier')
const panierInitial = panierLocalStorage ? JSON.parse(panierLocalStorage) : []

export function createStore() {
  return vuexCreateStore({
    state: {
      articles: articlesInitiaux,
      panier: panierInitial,
      isLoggedIn: localStorage.getItem('isLoggedIn') === 'true',
      user: null
    },
    mutations: {
      ajouterArticle(state, nouvelArticle) {
        // Générer un nouvel ID (simple incrémentation)
        const maxId = Math.max(...state.articles.map(a => a.id), 0)
        nouvelArticle.id = maxId + 1
        state.articles.push(nouvelArticle)
      },
      supprimerArticle(state, id) {
        state.articles = state.articles.filter(article => article.id !== id)
        // Supprimer aussi du panier si présent
        state.panier = state.panier.filter(article => article.id !== id)
        // Mise à jour du localStorage
        localStorage.setItem('panier', JSON.stringify(state.panier))
      },
      ajouterAuPanier(state, article) {
        // Vérifier si l'article est déjà dans le panier
        const existeDeja = state.panier.find(a => a.id === article.id)
        if (!existeDeja) {
          state.panier.push(article)
          // Mise à jour du localStorage
          localStorage.setItem('panier', JSON.stringify(state.panier))
        }
      },
      supprimerDuPanier(state, id) {
        state.panier = state.panier.filter(article => article.id !== id)
        // Mise à jour du localStorage
        localStorage.setItem('panier', JSON.stringify(state.panier))
      },
      viderPanier(state) {
        state.panier = []
        // Mise à jour du localStorage
        localStorage.setItem('panier', JSON.stringify(state.panier))
      },
      setLoggedIn(state, value) {
        state.isLoggedIn = value
        localStorage.setItem('isLoggedIn', value)
      },
      setUser(state, user) {
        state.user = user
      }
    },
    actions: {
      async login({ commit }, credentials) {
        // Validation basique de l'email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        if (!emailRegex.test(credentials.email)) {
          throw new Error('Format d\'email invalide')
        }
        
        // Vérification que le mot de passe n'est pas vide
        if (!credentials.password || credentials.password.trim() === '') {
          throw new Error('Le mot de passe est requis')
        }

        // Si les validations passent, on connecte l'utilisateur
        commit('setLoggedIn', true)
        commit('setUser', { email: credentials.email })
        return true
      },
      logout({ commit }) {
        commit('setLoggedIn', false)
        commit('setUser', null)
        localStorage.removeItem('isLoggedIn')
      }
    },
    getters: {
      getArticleById: (state) => (id) => {
        return state.articles.find(article => article.id === parseInt(id))
      },
      getArticlesFiltered: (state) => (recherche) => {
        if (!recherche) return state.articles
        const termeRecherche = recherche.toLowerCase()
        return state.articles.filter(article => 
          article.titre.toLowerCase().includes(termeRecherche) || 
          article.description.toLowerCase().includes(termeRecherche)
        )
      },
      getTotalPanier: (state) => {
        return state.panier.reduce((total, article) => total + article.prix, 0)
      }
    }
  })
}