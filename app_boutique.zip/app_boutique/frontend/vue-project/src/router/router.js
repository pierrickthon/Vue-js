import { createRouter, createWebHistory } from 'vue-router';
import HomeView from '../views/HomeView.vue';
import AjouterArticleView from '../views/AjouterArticleView.vue';
import ListeArticles from '../components/ListeArticles.vue';
import PanierView from '../views/PanierView.vue';
import AdminView from '../views/AdminView.vue';
import LoginView from '../views/LoginView.vue'

const routes = [
  { 
    path: '/login', 
    name: 'Login',
    component: LoginView
  },
  { 
    path: '/',
    name: 'Home',
    component: HomeView,
    meta: { requiresAuth: true }
  },
  { 
    path: '/articles', 
    name: 'Articles',
    component: ListeArticles,
    meta: { requiresAuth: true }
  },
  { 
    path: '/ajouter', 
    name: 'Ajouter',
    component: AjouterArticleView,
    meta: { requiresAuth: true }
  },
  { 
    path: '/panier', 
    name: 'Panier',
    component: PanierView,
    meta: { requiresAuth: true }
  },
  { 
    path: '/admin', 
    name: 'Admin',
    component: AdminView,
    meta: { requiresAuth: true }
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true'

  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!isLoggedIn) {
      next('/login')
    } else {
      next()
    }
  } else {
    next()
  }
})

export default router;